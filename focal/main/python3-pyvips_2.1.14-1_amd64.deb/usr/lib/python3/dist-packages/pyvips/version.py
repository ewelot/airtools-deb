# this is execfile()d into setup.py imported into __init__.py
__version__ = '2.1.14'

__all__ = ['__version__']
